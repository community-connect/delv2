var express = require('express');
var mysql = require('mysql2');
var app = express();


//database connection
global.database = mysql.createConnection({
    host: "bpxxsqkegtgglbmdsk7i-mysql.services.clever-cloud.com",
    // user: process.env.USER,
    user: "uuofqr8noewxa5k1",
    database: "bpxxsqkegtgglbmdsk7i",
    password: "mfM521mfkveIJ5utasdX",
  });

//static routes
app.use(express.static('public'));

app.get('/user-list', function(req, res) {
    var sql='SELECT * FROM Orders';
    database.query(sql, function (err, data, fields) {
    if (err) throw err;
    res.json(data);
  });
});



app.post('/order-details', function(req, res) {
  var id=req.query.p;
  var store=req.query.m;
  //console.log(store);
  var sql='SELECT * FROM Card_details where card_id='+id+' AND Shop="'+store+'"';
  database.query(sql, function (err, data, fields) {
  if (err) throw err;
  res.json(data);
});
});

app.get('/customer-ordered/:it', function(req, res) {
  console.log(req.params.it);
  var sql='SELECT DISTINCT Customer FROM Card_details where shop = "'+req.params.it+'"';
  database.query(sql, function (err, data, fields) {
  if (err) throw err;
  res.json(data);
});
});

app.get('/order-cu-details', function(req, res) {
  console.log('Database retrived customer who ordered in the card');
  var sql='SELECT * FROM User_order where OrderId=1000';
  database.query(sql, function (err, data, fields) {
  if (err) throw err;
  res.json(data);
});
});

app.post('/update-shop-status', function(req, res) {
  var store=req.query.m;
  console.log('collectef from shop');
  var sql="update Orders set collected = 1 where ShopName='"+store+"'";
  database.query(sql, function (err, data, fields) {
  if (err) throw err;
  res.json(data);
});
});


app.post('/order-details-cus', function(req, res) {
  var id=req.query.p;
  var cus=req.query.m;
  //console.log(store);
  var sql='SELECT * FROM Card_details where card_id='+id+' AND Customer="'+cus+'"';
  database.query(sql, function (err, data, fields) {
  if (err) throw err;
  res.json(data);
});
});




app.listen(8000,(err)=>{
    console.log(err);
})